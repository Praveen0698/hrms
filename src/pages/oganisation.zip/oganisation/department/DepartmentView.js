import React, { useEffect, useState } from "react";
import axios from "axios";

import { Link, useNavigate } from "react-router-dom";
import SideBar from "../../../components/SideBar";
import Header from "../../../components/Header";

import Button from "@mui/material/Button";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import { MdAdd } from "react-icons/md";
import Collapse from "@mui/material/Collapse";
import { BiSolidHide } from "react-icons/bi";
import { Card } from "@mui/material";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

import * as api from "./api"
import DepartmentTable from "./DepartmentTable";

const DepartmentView = () => {


  const getCurrentDate = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = `${now.getMonth() + 1}`.padStart(2, '0');
    const day = `${now.getDate()}`.padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [formVisible, setFormVisible] = useState(false);
  const [toggle, setToggle] = useState(false);
  const [department, setDepartment] = useState([]);
  const [search, setSearch] = useState("");
  const [company, setCompany] = useState([]);
  const [location, setLocation] = useState([]);
  const handleButtonClick = () => {
    setFormVisible((prev) => !prev);
  };

  let navigate = useNavigate();

  const [formData, setFormData] = useState({
    departmentName: "",
    companyName: "",
    email:"",
    locationName: "",
    departmentHead: "",
    createdDate: getCurrentDate(),
  });

  const [email,setEmail] = useState("")
  const [isEmailValid,setIsEmailValid] = useState(true)

  const handleInputChange = (e) => {
    const { name, value} = e.target;
    if (name === 'createdDate') {
      const isValidDate = value === getCurrentDate();
      setDateError(!isValidDate);
    }
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
      [name]: value,
    });
  };

  const saveDepartment = async () => {
    
    await api.saveDepartment(formData);
    alert("Department added successfully");
    navigate("/organisation/department ");
    loadDepartment();
    setFormData({
      locationName: "",
      departmentName: "",
      companyName: "",
      locationName: "",
      departmentHead: "",
      createdDate: "",
    });
  };

  const handleSubmit = (e) => {
    console.log("Form submitted:", formData);
  };

  useEffect(() => {
    loadDepartment();
    fetchCompany();
   
  }, []);
  console.log(department);

  const loadDepartment = async () => {
    const result = await api.loadDepartment()
    // console.log(result.data);
    setDepartment(result);
  };

  console.log(company)

  const fetchCompany = async () => {
    const companyData = await api.fetchCompanies()
    setCompany(companyData)
  };

  const [dateError, setDateError] = useState(false);

  const fetchLocation = async () => {
   const locationData = await api.fetchLocations()
   setLocation(locationData)
  };

  const [recDelete,setRecDelete] = useState("")
  console.log("dep",recDelete)

  const handleDelete = async () => {
    await api.deleteDepartment(recDelete)
    loadDepartment();
  };

  useEffect(() => {
    handleDelete()
  })
  const Head = [
    {
      value: "Choose",
      label: "Select Depatment Name",
    },
    {
      value: "Sarmistha Jena",
      label: "Sarmistha Jena",
    },
    {
      value: "Sumit Rana",
      label: "Sumit Rana",
    },
    {
      value: "Smruti Sourav",
      label: "Smruti Sourav",
    },
    {
      value: "Pritam Behera",
      label: "Pritam Behera",
    },
    {
      value: "Praveen Khuntia",
      label: "Praveen Khuntia",
    },
    {
      value: "Hrushikesh Jena",
      label: "Hrushikesh Jena",
    },
    {
      value: "Subhashree Das",
      label: "Subhashree Das",
    },
  ];

  const Type = [
    {
      value: "Choose",
      label: "Select Depatment Name",
    },
    {
      value: "Human Resources Department",
      label: "Human Resources Department",
    },
    {
      value: "Marketing Department",
      label: "Marketing Department",
    },
    {
      value: "Finance Department",
      label: "Finance Department",
    },
    {
      value: "Information Technology Department",
      label: "Information Technology Department",
    },
    {
      value: "Customer Service Department",
      label: "Customer Service Department",
    },
    {
      value: "Research and Development Department",
      label: "Research and Development Department",
    },
    {
      value: "Legal Department",
      label: "Legal Department",
    },
  ];

  




  return (
    <div>
      <Header />
      <div className="dashboard-container">
        <SideBar />
        <div className="head-foot-part">
          <section>
            <div
              className="above-table"
              style={{ display: "flex", justifyContent: "space-between" }}
            >
              <div>
                <Button
                  variant="outlined"
                  onClick={() => {
                    setToggle(!toggle);
                    handleButtonClick();
                  }}
                  style={{ height: "35px",marginBottom:"10px" }}
                >
                  {toggle ? (
                    <div className="hide">
                      <BiSolidHide
                      />
                      HIDE
                    </div>
                  ) : (
                    <div className="add">
                      <MdAdd />
                      ADD DEPARTMENT
                    </div>
                  )}
                </Button>
              </div>
            </div>
            <Collapse in={formVisible}>
              <Card
                variant="outlined"
                style={{ boxShadow: " 1px 1px 10px black" }}
              >
                <div style={{ marginTop: "20px" }}>
                  <h3
                    style={{
                      textAlign: "center",
                      marginTop: "25px",
                      fontWeight: "600",
                    }}
                  >
                    <h3> DEPARTMENT FORM</h3>
                  </h3>
                  <DialogContent>
                    <form onSubmit={handleSubmit}>
                      <div className="data-input-fields">
                        <TextField
                          id="departmentName"
                          margin="dense"
                          select
                          label="Department Name"
                          fullWidth
                          defaultValue="Choose"
                          SelectProps={{
                            native: true,
                          }}
                          InputLabelProps={{
                            shrink: true,
                          }}
                          value={formData.departmentName}
                          onChange={(e) => handleInputChange(e)}
                          name="departmentName"
                        >
                         {Type.map((option) => (
                              <MenuItem key={option.value} value={option.value}>
                                {option.label}
                              </MenuItem>
                            ))}
                        </TextField>

                        <TextField
                          id="companyName"
                          margin="dense"
                          select
                          label="Company Name"
                          fullWidth
                          defaultValue="Choose"
                          SelectProps={{
                            native: true,
                          }}
                          InputLabelProps={{
                            shrink: true,
                          }}
                          value={formData.companyName}
                          onChange={(e) => handleInputChange(e)}
                          name="companyName"
                        >
                          {company.map((option, index) => (
                            <MenuItem key={index} value={option.companyName}>
                              {option.companyName}
                            </MenuItem>
                          ))}
                        </TextField>
                      </div>
                      <div className="data-input-fields">
                        <TextField
                          id="departmentHead"
                          margin="dense"
                          select
                          label="Department Head"
                          fullWidth
                          defaultValue="Choose"
                          SelectProps={{
                            native: true,
                          }}
                          InputLabelProps={{
                            shrink: true,
                          }}
                          value={formData.departmentHead}
                          onChange={(e) => handleInputChange(e)}
                          name="companyType"
                        >
                          {Head.map((option) => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </TextField>

                        <TextField
                        margin="dense"
                        label="Create Date"
                        type="date"
                        fullWidth
                        name="createdDate"
                        id="createdDate"
                        value={formData.createdDate}
                        onChange={(e) => handleInputChange(e)}
                        required
                        error={dateError}
                        helperText={dateError && "Please select the current date"}
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                      </div>

                      <DialogActions>

                      <div className="data-buttons">
                      <Button
                          variant="outlined"
                          type="submit"
                          onClick={saveDepartment}
                          style={{
                            background:
                              "linear-gradient(to right, #1cb5e0, #000046)",
                            height: "35px",
                            width: "100%",
                            color: "white",
                          }}
                        >
                          Submit
                        </Button>
                        <Button
                          variant="outlined"
                          onClick={() => setFormVisible(false)}
                          style={{
                            background:
                              "linear-gradient(to left, #1cb5e0, #000046)",
                            height: "35px",
                            width: "100%",
                            color: "white",
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                        
                      </DialogActions>
                    </form>
                  </DialogContent>
                </div>
              </Card>
            </Collapse>
            <DepartmentTable department={department} setRecDelete={setRecDelete}/>
          </section>
        </div>
      </div>
    </div>
  );
};

export default DepartmentView;
